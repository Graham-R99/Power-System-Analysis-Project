% Initial setup
    a = 0.5; % initial guess for a
    b = -1; % initial guess for b
    max = 10; % maximum number of iterations
    ep = 0.0001; % convergence criterion

    fprintf('Iteration\t a\t\t b\t\t |Delta x|\n');

    % Iteration
    for iter = 1:max
        %  function values
        F = [a^2 + b^2 - 4; exp(a) + b - 1];

        %Jacobian matrix
        J = [2*a, 2*b; exp(a), 1];

        % Update rule
        delta = J \ F;
        a_new = a - delta(1);
        b_new = b - delta(2);

        % Display current iteration details
        fprintf('%d\t\t %f\t %f\t %f\n', iter, a_new, b_new, norm(delta));

        %convergence
        if norm(delta) <= ep
            fprintf('Converged at iteration %d\n', iter);
            break;
        end

        % Update a and b
        a = a_new;
        b = b_new;
    end

    % If maximum iterations reached
    if iter == max
        fprintf('Maximum iterations reached without convergence.\n');
    return;
end;
