%initial
    old = 2; 
    max = 100; 
    ep = 0.001; 
    fprintf('Iteration\t h(x)\t\t Delta x\t x\n');

    % Iteration
    for iter = 1:max
        new = nthroot(9 * old, 3); 
        delta_x = abs(new - old);
        
        %current iteration details
        fprintf('%d\t\t %f\t %f\t %f\n', iter, new, delta_x, new);

        % convergence
        if delta_x <= ep
            fprintf('Converged at iteration %d\n', iter);
            break;
        end

        % Update old for the next iteration
        old = new;
    end

   
    if iter == max
        fprintf('Maximum iterations reached without convergence.\n');
    return;
end;